# Event Manager

A structured, collaborative event coordination platform designed initially for Haven Home Support, now open-sourced for broader use cases in education, care coordination, and compliance tracking.

## 🔍 Overview

- Google Sheets + Apps Script backbone
- Dynamic Gantt chart views
- Fully role-based permissions
- Form-driven data entry and repeat scheduling
- Optional email triggers and user-specific dashboards

## 📂 Folder Structure

- `/docs/` – Architecture, workflows, and UX specs  
- `/scripts/` – Apps Script or server logic  
- `/forms/` – Survey or input form mockups  
- `/templates/` – Email, report, and export templates  
- `change_log.txt` – Machine-readable changes  
- `devlog.md` – Human-readable thoughts and progress

## 👥 Contributors

- **Scott Neels** (Kiwi-Scott) — Project lead and core developer  
- **ChatGPT_Legend** — Technical strategy and co-developer  
- **[Chris Bake / Stan’s Legacy](https://stanslegacy.com)** — Inspiration and community facilitator  

> 🔗 Discord: [Join the Community](https://discord.gg/BsekM2Dq)

---

## 📌 Notes

This repo connects with other community-driven hardware and simulation tools such as:

- [Nano Burst Generator](https://github.com/Kiwi-Scott/Nano-Burst_Generator)
- [Teensy Analog Scope Logger](https://github.com/Kiwi-Scott/Teensy_AnalogScope_Logger)
- [AI Optimized LCR Charging](https://github.com/Kiwi-Scott/AI_Optimized_DCM_LCR_Charging)
- [Braun–Stanley Layer](https://github.com/Kiwi-Scott/braun-stanley-layer)

---

> 🧠 Maintained with the help of GPT-4o (ChatGPT_Legend), August 2025.
